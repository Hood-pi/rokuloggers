# InterProcessCommunication-Samples

Code for my blog series<br>
#1 [Offensive Windows IPC Internals 1: Named Pipes](https://csandker.io/2021/01/10/Offensive-Windows-IPC-1-NamedPipes.html)<br>
#2 [Offensive Windows IPC Internals 2: RPC](https://csandker.io/2021/02/21/Offensive-Windows-IPC-2-RPC.html)<br>
#3 [Offensive Windows IPC Internals 3: ALPC](https://csandker.io/2022/05/24/Offensive-Windows-IPC-3-ALPC.html)